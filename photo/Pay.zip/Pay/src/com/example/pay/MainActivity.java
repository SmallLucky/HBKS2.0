package com.example.pay;

import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Order();
    }
    
    public void Order()
    {
        Map<String, String> map = new HashMap<String, String>();
//		String merchantNo = "898875475663024";
        String merchantNo = "5382000003";
        String orderAmount = "1000";
        String orderNo = "123456789012374";
        String notifyUrl = "http://wappay.vitongpay.com/apppay/bjbocNotify";
        String callbackUrl = "http://wappay.vitongpay.com/apppay/callback";
        String productName = "productName";
        String productDesc = "productDesc";
        String remark = "remark";
        map.put("merchantNo", merchantNo);
        map.put("orderAmount", orderAmount);
        map.put("orderNo", orderNo);
        map.put("notifyUrl", notifyUrl);
        map.put("callbackUrl", callbackUrl);
        map.put("productName", productName);
        map.put("productDesc", productDesc);
        map.put("remark", remark);
        map.put("payType", "3");

        String a = SignUtils.payParamsToString(map);
//		a = a+"9d101c97133837e13dde2d32a5054abb";
        a = a+"05d949c39913b7e0eb8f77c1dd9f92b8";
        Log.i("TAG", "sign����ǰ���ַ���="+a);
        System.out.println("��Կ=05d949c39913b7e0eb8f77c1dd9f92b8");
        String sign = MD5.md5Str(a).toUpperCase();
        Log.i("TAG", "MD5���ܺ�Ľ��="+sign);
        map.put("sign", sign);

        String url = "http://wappay.vitongpay.com/apppay/order";
//        String response = AndroidHttpClient.androidPost(url, map);
//        String response = AndroidHttpClient.post(url, map);
        String response = MyHttpClient.androidPost(url, map);
        Log.i("TAG", "response: " + response);
    }
}
