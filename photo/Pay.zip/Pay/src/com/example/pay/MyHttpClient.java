package com.example.pay;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import android.util.Log;

public class MyHttpClient {
    @SuppressWarnings("deprecation")
	public static String androidPost(String url, Map<String, String> map)
    {
    	HttpClient client = null;
    	HttpResponse response = null;
    	String res = null;
        try {
//        	HttpPost httpPost = new HttpPost();
//        	httpPost.setURI(new URI(url));
        	HttpPost httpPost = new HttpPost(url);	//the same
        		
        	List<NameValuePair> params = new ArrayList<NameValuePair>();
            for (Map.Entry entry : map.entrySet()) {
                params.add(new BasicNameValuePair((String) entry.getKey(),
                        (String) entry.getValue()));
                Log.i("TAG", "KEY:" + (String) entry.getKey()+"   VALUE:"+(String) entry.getValue());
            }
            
            HttpEntity  param = new UrlEncodedFormEntity(params,HTTP.UTF_8);  
            httpPost.setEntity(param);
            Log.i("TAG", "111");
            //client = new DefaultHttpClient(); 
        	client = new DefaultHttpClient(); 
            Log.i("TAG", "222");
            response = client.execute(httpPost);
            Log.i("TAG", "333");
            int statusCode = response.getStatusLine().getStatusCode();
            Log.i("TAG", "״̬��:"+statusCode);
            if (statusCode == HttpStatus.SC_OK) {
                if (response != null && response.getEntity() != null) {
                    // ��ȡ�ַ���
                    res = EntityUtils.toString(response.getEntity());
                    Log.i("TAG", "��ȡ�ַ���:"+res);
                    return res;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
